-- Product Information Table
DELETE FROM `product_information`;
INSERT INTO `product_information` (`title`, `popularity`, `reviewCount`, `starRate`, `price`, `alternatePrice`, `size`, `color`) VALUES
('The Doors Dress', '1', '60', '4.8', '32.68', '[{"Installments": "4", "Price": "8.17"}]', '[{"Size": "XS"}, {"Size": "S"}, {"Size": "M"}, {"Size": "L"}]',
'[{"id": "010", "Color": "White"}, {"id": "013", "Color": "Blue"}, {"id": "012", "Color": "Pink"}]'),
('The Cute Shirt', '1', '80', '3.0', '40.50', '[{"Installments": "4", "Price": "10.13"}]', '[{"Size": "XS"}, {"Size": "S"}, {"Size": "M"}, {"Size": "L"}]',
'[{"id": "009", "Color": "Yellow"}, {"id": "014", "Color": "Black"}, {"id": "012", "Color": "Pink"}]'),
('Nice Sweater', '0', '90', '4.5', '80', '[{"Installments": "4", "Price": "20"}]', '[{"Size": "XS"}, {"Size": "S"}, {"Size": "M"}, {"Size": "L"}]',
'[{"id": "009", "Color": "Yellow"}, {"id": "014", "Color": "Black"}, {"id": "012", "Color": "Pink"}]');
SELECT * FROM `product_information`;

-- Product Detail Table
DELETE FROM `product_detail`;
INSERT INTO `product_detail` (`id`, `styleNumber`, `colorCode`, `description`, `care`, `origin`) VALUES
('1', '0987', '010', 'description', 'Hand-Wash', 'US'),
('2', '587', '111', 'description', 'Wash Cold', 'US'),
('3', '111', '014', 'description', 'Dry-Cleaner', 'US');
SELECT * FROM `product_detail`;

-- Product Photo Table
DELETE FROM `product_photo`;
INSERT INTO `product_photo` (`id`, `cover`, `likeCount`, `selectedImage`, `accessoryImage`) VALUES
('1', 'cover.png', '1388', 'selectedImage.png', 'accessoryImage.png'),
('2', 'cover2.png', '2000', 'selectedImage2.png', 'accessoryImage2.png'),
('3', 'cover3.png', '300', 'selectedImage3.png', 'accessoryImage3.png');
SELECT * FROM `product_photo`;

-- Material Item Table
DELETE FROM `material_item`;
INSERT INTO `material_item` (`id`, `name`, `percent`) VALUES
('1', 'Cotton', '100'),
('2', 'Wool', '100');
SELECT * FROM `material_item`;

-- Material Table
DELETE FROM `material`;
INSERT INTO `material` (`id`) VALUES 
('1'), ('2');
SELECT * FROM `material`;

-- Material-Material Item Table
delete from `material-material_item`;
insert into `material-material_item` (`materialId`, `materialItemId`) values
('1', '1'),
('2', '1'),
('2', '2');
select `material`.*, `material-material_item`.*, `material_item`.*
from `material`
join `material-material_item` on `material-material_item`.materialId = `material`.id
join `material_item` on `material_item`.id = `material-material_item`.materialItemId;

-- Personal Review Table
DELETE FROM `personal_review`;
INSERT INTO `personal_review` (`id`, `username`, `location`, `age`, `bodyType`, `height`, `photo`, `star`, `title`, `description`, `fit`, 
`purchaseSize`, `usualSize`, `recommendStatus`, `date`) VALUES
('1', 'emilys', 'Seattle', '21', 'athletic', '5 foot 6 inch', 'photo.png', '5.0', 'so comfy', 'best dress ever', 'usual to size', '6', '6', '1', 'June 6th'),
('2', 'smokoff', 'Bellevue', '23', 'athletic', '5 foot 4 inch', 'photo.png', '4.0', 'very soft', 'lovely shirt', 'usual to size', '8', '8', '1', 'May 6th'),
('3', 'hello', 'Tacoma', '25', 'athletic', '5 foot 8 inch', 'photo.png', '3.0', 'very soft', 'lovely sweater', 'usual to size', '4', '4', '1', 'March 6th');
SELECT * FROM `personal_review`;

-- Page of Review Table
DELETE FROM `page_of_review`;
INSERT INTO `page_of_review` (`id`, `personalReviewId`) VALUES 
('1', '1'),
('2', '2'),
('3', '3');
select `page_of_review`.*, `personal_review`.*
from `personal_review`
join `page_of_review` on `page_of_review`.personalReviewId = `personal_review`.id;

-- Product Review Table
DELETE FROM `product_review`;
INSERT INTO `product_review` (`id`, `rating`, `reviewCount`, `percentRecommended`, `fitToSize`, `pageOfReviewId`) VALUES
('1', '4.8', '980', '97', 'Usual Fit', '1'),
('2', '4.0', '400', '90', 'Runs Big', '2'),
('3', '3.6', '1000', '80', 'Runs Small', '3');
select `page_of_review`.*, `product_review`.*
from `page_of_review`
join `product_review` on `product_review`.pageOfReviewId = `page_of_review`.id;

-- Product Table
DELETE FROM `product`;
INSERT INTO `product` (`id`, `productInformationTitle`, `productReviewId`, `productDetailId`, `productPhotoId`, `materialId`) VALUES
('1', 'The Doors Dress', '1', '1', '1', '1'),
('2', 'The Cute Shirt', '2', '2', '2', '1'),
('3', 'Nice Sweater', '3', '3', '3', '2');
select `product_information`.*, `product_review`.*, `product_detail`.*, `product_photo`.*, `material`.*, `product`.*
from `product_information`
join `product` on `product`.productInformationTitle = `product_information`.title
join `product_review` on `product_review`.id = `product`.productReviewId
join `product_detail` on `product_detail`.id = `product`.productDetailId
join `product_photo` on `product_photo`.id = `product`.productPhotoId
join `material` on `material`.id = `product`.materialId;

-- Shipping table
DELETE FROM `shipping`;
INSERT INTO `shipping` (`title`, `description`, `notice`, `shippingMethod`) VALUES
('US Shipping', 'Below are estimates', '*Orders cannot be expedited.', 
'[{"Method": "Standard", "Estimated Delivery": "5-8 days", "Price": "Free"}, 
{"Method": "Express", "Estimated Delivery": "2-3 days", "Price": "10.00"}]'),
('International Shipping', 'Below are estimates', '*Orders cannot be expedited.', 
'[{"Method": "Standard", "Estimated Delivery": "10-12 days", "Price": "Free"}, 
{"Method": "Express", "Estimated Delivery": "8-10 days", "Price": "20.00"}]');
SELECT * FROM `shipping`;

-- Store Pickup Table
DELETE FROM `store_pickup`;
INSERT INTO `store_pickup` (`title`, `description`, `notice`) VALUES
('In-Store Pickup', 'Most items available in 24 hours', 'Item is available'),
('Curbside Pickup', 'Most items available in 24 hours', 'Item is available');
SELECT * FROM `store_pickup`;

-- Return Table
DELETE FROM `return`;
INSERT INTO `return` (`title`, `description`, `returnPolicy`) VALUES 
('US Returns', 'Mail items back with paid label', 
'[{"Return Policy": "Within 30 days of delivery", "Return Method": "Original form of payment"}, 
{"Return Policy": "After 30 days of delivery", "Return Method": "e-gift card"}]'),
('International Returns', 'Mail items back with paid label', 
'[{"Return Policy": "Within 30 days of delivery", "Return Method": "Original form of payment"}, 
{"Return Policy": "After 30 days of delivery", "Return Method": "e-gift card"}]');
SELECT * FROM `return`;

-- Product Acquisition Table
DELETE FROM `product_acquisition`;
INSERT INTO `product_acquisition` (`id`, `shippingTitle`, `storePickupTitle`, `returnTitle`) VALUES
('1', 'US Shipping', 'In-Store Pickup', 'US Returns'),
('2', 'International Shipping', 'Curbside Pickup', 'International Returns');
select `shipping`.*, `store_pickup`.*, `return`.*, `product_acquisition`.*
from `shipping`
join `product_acquisition` on `product_acquisition`.shippingTitle = `shipping`.title
join `store_pickup` on `store_pickup`.title = `product_acquisition`.storePickupTitle
join `return` on `return`.title = `product_acquisition`.returnTitle;

-- Product-Product Acquisition Table
delete from `product-product_acquisition`;
insert into `product-product_acquisition` (`productId`, `productAcquisitionId`) values
(1,1),
(2,1),
(1,2),
(2,2),
(3,1),
(3,2);
select `product`.*, `product-product_acquisition`.*, `product_acquisition`.*
from `product`
join `product-product_acquisition` on `product-product_acquisition`.productId = `product`.id
join `product_acquisition` on `product_acquisition`.id = `product-product_acquisition`.productAcquisitionId;

-- Store Availability Table
DELETE FROM `store_availability`;
INSERT INTO `store_availability` (`id`, `city`, `storeAddress`, `availability`) VALUES
('1', 'Seattle', '5019 19th Ave', '0'),
('2', 'Bellevue', 'Brooklyn ave', '1');
SELECT * FROM `store_availability`;

-- Product-Store Availability Table
delete from `product-store_availability`;
insert into `product-store_availability` (`productId`, `storeAvailabilityId`) VALUES
(1,1),
(2,1),
(1,2),
(2,2),
(3,1),
(3,2);
select `product`.*, `product-store_availability`.*, `store_availability`.*
from `product`
join `product-store_availability` on `product-store_availability`.productId = `product`.id
join `store_availability` on `store_availability`.id = `product-store_availability`.storeAvailabilityId
