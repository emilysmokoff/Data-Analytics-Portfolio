CREATE DATABASE  IF NOT EXISTS `free_people` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `free_people`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: free_people
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `material`
--

DROP TABLE IF EXISTS `material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material`
--

LOCK TABLES `material` WRITE;
/*!40000 ALTER TABLE `material` DISABLE KEYS */;
/*!40000 ALTER TABLE `material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material-material_item`
--

DROP TABLE IF EXISTS `material-material_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material-material_item` (
  `materialId` int NOT NULL,
  `materialItemId` int NOT NULL,
  PRIMARY KEY (`materialId`,`materialItemId`),
  KEY `fromMaterialMaterialItemToMaterialItem_idx` (`materialItemId`),
  CONSTRAINT `fromMaterialMaterialItemToMaterial` FOREIGN KEY (`materialId`) REFERENCES `material` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromMaterialMaterialItemToMaterialItem` FOREIGN KEY (`materialItemId`) REFERENCES `material_item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material-material_item`
--

LOCK TABLES `material-material_item` WRITE;
/*!40000 ALTER TABLE `material-material_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `material-material_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_item`
--

DROP TABLE IF EXISTS `material_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `percent` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_item`
--

LOCK TABLES `material_item` WRITE;
/*!40000 ALTER TABLE `material_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `material_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_of_review`
--

DROP TABLE IF EXISTS `page_of_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_of_review` (
  `id` int NOT NULL AUTO_INCREMENT,
  `personalReviewId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromPageOfReviewToPersonalReview_idx` (`personalReviewId`),
  CONSTRAINT `fromPageOfReviewToPersonalReview` FOREIGN KEY (`personalReviewId`) REFERENCES `personal_review` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_of_review`
--

LOCK TABLES `page_of_review` WRITE;
/*!40000 ALTER TABLE `page_of_review` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_of_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_review`
--

DROP TABLE IF EXISTS `personal_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_review` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `location` varchar(100) DEFAULT NULL,
  `age` varchar(100) DEFAULT NULL,
  `bodyType` varchar(100) DEFAULT NULL,
  `height` varchar(100) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `star` float NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `fit` varchar(100) NOT NULL,
  `purchaseSize` int NOT NULL,
  `usualSize` int NOT NULL,
  `recommendStatus` tinyint(1) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_review`
--

LOCK TABLES `personal_review` WRITE;
/*!40000 ALTER TABLE `personal_review` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productInformationTitle` varchar(100) NOT NULL,
  `productReviewId` int NOT NULL,
  `productDetailId` int NOT NULL,
  `productPhotoId` int NOT NULL,
  `materialId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromProductToProductInformation_idx` (`productInformationTitle`),
  KEY `fromProductToProductReview_idx` (`productReviewId`),
  KEY `fromProductToProductDetail_idx` (`productDetailId`),
  KEY `fromProductToProductPhoto_idx` (`productPhotoId`),
  KEY `fromProductToMaterial_idx` (`materialId`),
  CONSTRAINT `fromProductToMaterial` FOREIGN KEY (`materialId`) REFERENCES `material` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductToProductDetail` FOREIGN KEY (`productDetailId`) REFERENCES `product_detail` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductToProductInformation` FOREIGN KEY (`productInformationTitle`) REFERENCES `product_information` (`title`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductToProductPhoto` FOREIGN KEY (`productPhotoId`) REFERENCES `product_photo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductToProductReview` FOREIGN KEY (`productReviewId`) REFERENCES `product_review` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product-product_acquisition`
--

DROP TABLE IF EXISTS `product-product_acquisition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product-product_acquisition` (
  `productId` int NOT NULL,
  `productAcquisitionId` int NOT NULL,
  PRIMARY KEY (`productId`,`productAcquisitionId`),
  KEY `fromProductProductAcquisitionToProductAcquisition_idx` (`productAcquisitionId`),
  CONSTRAINT `fromProductProductAcquisitionToProduct` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductProductAcquisitionToProductAcquisition` FOREIGN KEY (`productAcquisitionId`) REFERENCES `product_acquisition` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product-product_acquisition`
--

LOCK TABLES `product-product_acquisition` WRITE;
/*!40000 ALTER TABLE `product-product_acquisition` DISABLE KEYS */;
/*!40000 ALTER TABLE `product-product_acquisition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product-store_availability`
--

DROP TABLE IF EXISTS `product-store_availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product-store_availability` (
  `productId` int NOT NULL,
  `storeAvailabilityId` int NOT NULL,
  PRIMARY KEY (`productId`,`storeAvailabilityId`),
  KEY `fromProductStoreAvailabilityToStoreAvailability_idx` (`storeAvailabilityId`),
  CONSTRAINT `fromProductStoreAvailabilityToProduct` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductStoreAvailabilityToStoreAvailability` FOREIGN KEY (`storeAvailabilityId`) REFERENCES `store_availability` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product-store_availability`
--

LOCK TABLES `product-store_availability` WRITE;
/*!40000 ALTER TABLE `product-store_availability` DISABLE KEYS */;
/*!40000 ALTER TABLE `product-store_availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_acquisition`
--

DROP TABLE IF EXISTS `product_acquisition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_acquisition` (
  `id` int NOT NULL AUTO_INCREMENT,
  `shippingTitle` varchar(100) NOT NULL,
  `storePickupTitle` varchar(100) NOT NULL,
  `returnTitle` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromProductAcquisitionToShipping_idx` (`shippingTitle`),
  KEY `fromProductAcquisitionToStorePickup_idx` (`storePickupTitle`),
  KEY `fromProductAcquisitionToReturn_idx` (`returnTitle`),
  CONSTRAINT `fromProductAcquisitionToReturn` FOREIGN KEY (`returnTitle`) REFERENCES `return` (`title`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductAcquisitionToShipping` FOREIGN KEY (`shippingTitle`) REFERENCES `shipping` (`title`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductAcquisitionToStorePickup` FOREIGN KEY (`storePickupTitle`) REFERENCES `store_pickup` (`title`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_acquisition`
--

LOCK TABLES `product_acquisition` WRITE;
/*!40000 ALTER TABLE `product_acquisition` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_acquisition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_detail`
--

DROP TABLE IF EXISTS `product_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `styleNumber` int NOT NULL,
  `colorCode` int NOT NULL,
  `description` varchar(200) NOT NULL,
  `care` varchar(100) NOT NULL,
  `origin` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_detail`
--

LOCK TABLES `product_detail` WRITE;
/*!40000 ALTER TABLE `product_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_information`
--

DROP TABLE IF EXISTS `product_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_information` (
  `title` varchar(100) NOT NULL,
  `popularity` tinyint(1) NOT NULL,
  `reviewCount` int NOT NULL,
  `starRate` float NOT NULL,
  `price` float NOT NULL,
  `alternatePrice` json NOT NULL,
  `size` json NOT NULL,
  `color` json NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_information`
--

LOCK TABLES `product_information` WRITE;
/*!40000 ALTER TABLE `product_information` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_photo`
--

DROP TABLE IF EXISTS `product_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_photo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cover` varchar(100) NOT NULL,
  `likeCount` int NOT NULL,
  `selectedImage` varchar(100) NOT NULL,
  `accessoryImage` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_photo`
--

LOCK TABLES `product_photo` WRITE;
/*!40000 ALTER TABLE `product_photo` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_photo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_review`
--

DROP TABLE IF EXISTS `product_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_review` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rating` float NOT NULL,
  `reviewCount` int NOT NULL,
  `percentRecommended` int NOT NULL,
  `fitToSize` varchar(100) NOT NULL,
  `pageOfReviewId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromProductReviewToPageOfReview_idx` (`pageOfReviewId`),
  CONSTRAINT `fromProductReviewToPageOfReview` FOREIGN KEY (`pageOfReviewId`) REFERENCES `page_of_review` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_review`
--

LOCK TABLES `product_review` WRITE;
/*!40000 ALTER TABLE `product_review` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return`
--

DROP TABLE IF EXISTS `return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `return` (
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `returnPolicy` json NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return`
--

LOCK TABLES `return` WRITE;
/*!40000 ALTER TABLE `return` DISABLE KEYS */;
/*!40000 ALTER TABLE `return` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping`
--

DROP TABLE IF EXISTS `shipping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipping` (
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `notice` varchar(100) NOT NULL,
  `shippingMethod` json NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping`
--

LOCK TABLES `shipping` WRITE;
/*!40000 ALTER TABLE `shipping` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_availability`
--

DROP TABLE IF EXISTS `store_availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_availability` (
  `id` int NOT NULL AUTO_INCREMENT,
  `city` varchar(100) NOT NULL,
  `storeAddress` varchar(100) NOT NULL,
  `availability` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_availability`
--

LOCK TABLES `store_availability` WRITE;
/*!40000 ALTER TABLE `store_availability` DISABLE KEYS */;
/*!40000 ALTER TABLE `store_availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_pickup`
--

DROP TABLE IF EXISTS `store_pickup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_pickup` (
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `notice` varchar(100) NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_pickup`
--

LOCK TABLES `store_pickup` WRITE;
/*!40000 ALTER TABLE `store_pickup` DISABLE KEYS */;
/*!40000 ALTER TABLE `store_pickup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-30 23:06:19
